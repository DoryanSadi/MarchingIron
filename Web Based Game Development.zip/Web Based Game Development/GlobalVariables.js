// Declare MIGame, the object which holds the games states. 
var MIGame = {
    
//Defining game states. 
scenes: [], 
    

//Defining common framerate to be referenced. 
FrameRate: 10
    
}; 